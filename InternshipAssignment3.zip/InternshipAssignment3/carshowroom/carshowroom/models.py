import pymysql

class DBOperations:
    def loginuser(self, uid, psw):
        status = None
        try:
            con = pymysql.connect(host='bjdnzwywx4yuwlv2yvqn-mysql.services.clever-cloud.com', user='uryhne0taq31lhab', password='9ktaVYjniKvGj207ouvQ', database='bjdnzwywx4yuwlv2yvqn')
            curs=con.cursor()
            curs.execute("select * from users")
            data = curs.fetchall()
            for i in range(0,4):
                if uid == data[i][0] and psw == data[i][1]:
                    status='success'
            con.close()
        except:
            status='error'
        return status
    
    def addcar(self, id, nm, comp, typ, whls, encp, ftyp, prc, img):
        status = None
        try:
            con = pymysql.connect(host='bjdnzwywx4yuwlv2yvqn-mysql.services.clever-cloud.com', user='uryhne0taq31lhab', password='9ktaVYjniKvGj207ouvQ', database='bjdnzwywx4yuwlv2yvqn')
            curs=con.cursor()
            curs.execute("insert into cars values(%d,'%s','%s','%s',%d,%d,'%s',%.2f,'%s')" %(id, nm, comp, typ, whls, encp, ftyp, prc, img))
            con.commit()
            con.close()
            status='success'
        except:
            status='error'
        return status
    #(carid,carname,company,type,wheels,enginecap,fueltype,price,image)

    def addcust(self, id, nm, mob, email, add, carid):
        status = None
        try:
            con = pymysql.connect(host='bjdnzwywx4yuwlv2yvqn-mysql.services.clever-cloud.com', user='uryhne0taq31lhab', password='9ktaVYjniKvGj207ouvQ', database='bjdnzwywx4yuwlv2yvqn')
            curs=con.cursor()
            curs.execute("insert into customers values(%d,'%s','%s','%s','%s',%d)" %(id, nm, mob, email, add, carid))
            con.commit()
            con.close()
            status='success'
        except:
            status='error'
        return status
    
    def getcars(self):
        con = pymysql.connect(host='bjdnzwywx4yuwlv2yvqn-mysql.services.clever-cloud.com', user='uryhne0taq31lhab', password='9ktaVYjniKvGj207ouvQ', database='bjdnzwywx4yuwlv2yvqn')
        curs = con.cursor()
        curs.execute("select * from cars")
        data = curs.fetchall()
        return data
    
    def getcustomers(self):
        con = pymysql.connect(host='bjdnzwywx4yuwlv2yvqn-mysql.services.clever-cloud.com', user='uryhne0taq31lhab', password='9ktaVYjniKvGj207ouvQ', database='bjdnzwywx4yuwlv2yvqn')
        curs = con.cursor()
        curs.execute("select * from customers")
        data = curs.fetchall()
        return data
    
    def modifyprice(self, id, newprc):
        status = None
        try:
            con = pymysql.connect(host='bjdnzwywx4yuwlv2yvqn-mysql.services.clever-cloud.com', user='uryhne0taq31lhab', password='9ktaVYjniKvGj207ouvQ', database='bjdnzwywx4yuwlv2yvqn')
            curs = con.cursor()
            curs.execute("update cars set price=%.2f where carid=%d" %(newprc,id))
            con.commit()
            con.close()
            status = 'success'
        except:
            status = 'error'
        return status
    
    def modifymobno(self, id, mobno):
        status = None
        try:
            con = pymysql.connect(host='bjdnzwywx4yuwlv2yvqn-mysql.services.clever-cloud.com', user='uryhne0taq31lhab', password='9ktaVYjniKvGj207ouvQ', database='bjdnzwywx4yuwlv2yvqn')
            curs = con.cursor()
            curs.execute("update customers set mobileno='%s' where customerid=%d" %(mobno,id))
            con.commit()
            con.close()
            status = 'success'
        except:
            status = 'error'
        return status
    
    def searchcustbyid(self, id):
        con = pymysql.connect(host='bjdnzwywx4yuwlv2yvqn-mysql.services.clever-cloud.com', user='uryhne0taq31lhab', password='9ktaVYjniKvGj207ouvQ', database='bjdnzwywx4yuwlv2yvqn')
        curs = con.cursor()
        curs.execute("select * from customers where customerid=%d" %(id))
        data = curs.fetchone()
        return data
    
    def searchcustbynm(self, nm):
        con = pymysql.connect(host='bjdnzwywx4yuwlv2yvqn-mysql.services.clever-cloud.com', user='uryhne0taq31lhab', password='9ktaVYjniKvGj207ouvQ', database='bjdnzwywx4yuwlv2yvqn')
        curs = con.cursor()
        curs.execute("select * from customers where name='%s'" %(nm))
        data = curs.fetchone()
        return data
    
    def searchcar(self, id):
        con = pymysql.connect(host='bjdnzwywx4yuwlv2yvqn-mysql.services.clever-cloud.com', user='uryhne0taq31lhab', password='9ktaVYjniKvGj207ouvQ', database='bjdnzwywx4yuwlv2yvqn')
        curs = con.cursor()
        curs.execute("select * from cars where carid=%d" %(id))
        data = curs.fetchone()
        return data
    
    def searchcarcompwise(self, comp):
        con = pymysql.connect(host='bjdnzwywx4yuwlv2yvqn-mysql.services.clever-cloud.com', user='uryhne0taq31lhab', password='9ktaVYjniKvGj207ouvQ', database='bjdnzwywx4yuwlv2yvqn')
        curs = con.cursor()
        curs.execute("select * from cars where company='%s'" %(comp))
        data = curs.fetchall()
        return data
    
    def searchcartypewise(self, type):
        con = pymysql.connect(host='bjdnzwywx4yuwlv2yvqn-mysql.services.clever-cloud.com', user='uryhne0taq31lhab', password='9ktaVYjniKvGj207ouvQ', database='bjdnzwywx4yuwlv2yvqn')
        curs = con.cursor()
        curs.execute("select * from cars where type='%s'" %(type))
        data = curs.fetchall()
        return data